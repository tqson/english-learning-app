<?php
session_start();
define('BASE_URL', 'http://localhost:63343/member_system');
?>