</div>
    <footer class="footer">
        <p>&copy; 2025 TQSON.</p>
    </footer>
</body>
</html>