<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management System</title>
<!--    <link rel="stylesheet" href="--><?php //echo BASE_URL; ?><!--/assets/css/style.css">-->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">MySystem</div>
        <ul class="nav-links">
            <li><a href="<?php echo BASE_URL; ?>/pages/index.php">Home</a></li>
            <?php if(isset($_SESSION['user_id'])): ?>
			        <li><a href="<?php echo BASE_URL; ?>/pages/profile.php">Profile</a></li>
			        <li><a href="<?php echo BASE_URL; ?>/pages/logout.php">Logout</a></li>
            <?php else: ?>
			        <li><a href="<?php echo BASE_URL; ?>/pages/login.php">Login</a></li>
			        <li><a href="<?php echo BASE_URL; ?>/pages/register.php">Register</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <div class="container">