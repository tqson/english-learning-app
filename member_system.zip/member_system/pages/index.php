<?php
require_once '../includes/config.php';
require_once '../includes/header.php';
?>

	<div class="welcome-section">
    <h1>Welcome to User Management System</h1>
      <?php if (isset($_SESSION['user_id'])): ?>
				<p>Hello, <?php echo $_SESSION['username']; ?>!</p>
      <?php else: ?>
				<p>Please login or register to continue.</p>
      <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>