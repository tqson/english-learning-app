<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Simple validation
    if ($email == "admin@example.com" && $password == "password") {
        $_SESSION['user_id'] = 1;
        $_SESSION['username'] = "Admin";
        $_SESSION['email'] = $email;

        if (isset($_POST['remember'])) {
            setcookie('user_email', $email, time() + (86400 * 30), "/");
        }

        header("Location: profile.php");
        exit();
    } else {
        $error = "Invalid credentials";
    }
}

require_once '../includes/header.php';
?>

    <div class="form-container">
    <h2>Login</h2>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
        <?php endif; ?>

        <form method="POST" action="">
        <div class="form-group">
            <label>Email:</label>
            <input type="email" name="email" value="<?php echo isset($_COOKIE['user_email']) ? $_COOKIE['user_email'] : ''; ?>">
        </div>

        <div class="form-group">
            <label>Password:</label>
            <input type="password" name="password">
        </div>

        <div class="form-group">
            <label>
                <input type="checkbox" name="remember"> Remember me
            </label>
        </div>

        <button type="submit" class="btn">Login</button>
    </form>
</div>

<?php require_once '../includes/footer.php'; ?>