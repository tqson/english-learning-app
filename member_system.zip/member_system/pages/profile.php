<?php
require_once '../includes/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require_once '../includes/header.php';
?>

	<div class="form-container">
    <h2>Profile</h2>

    <div class="profile-info">
        <p><strong>Username:</strong> <?php echo $_SESSION['username']; ?></p>
        <p><strong>Email:</strong> <?php echo $_SESSION['email']; ?></p>
    </div>

      <?php if(isset($_COOKIE['user_email'])): ?>
				<p>Your email is remembered for easy login!</p>
      <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>