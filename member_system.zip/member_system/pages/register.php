<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate input
    $errors = [];
    if (empty($username)) $errors[] = "Username is required";
    if (empty($email)) $errors[] = "Email is required";
    if (empty($password)) $errors[] = "Password is required";

    if (empty($errors)) {
        // In thực tế sẽ lưu vào database
        $_SESSION['user_id'] = 1;
        $_SESSION['username'] = $username;
        $_SESSION['email'] = $email;

        // Set cookie
        setcookie('user_email', $email, time() + (86400 * 30), "/");

        header("Location: profile.php");
        exit();
    }
}

require_once '../includes/header.php';
?>

<div class="form-container">
    <h2>Register</h2>

    <?php if (!empty($errors)): ?>
			<div class="alert alert-danger">
            <?php foreach ($errors as $error): ?>
	            <p><?php echo $error; ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

	<form method="POST" action="">
        <div class="form-group">
            <label>Username:</label>
            <input type="text" name="username"
                   value="<?php echo isset($_POST['username']) ? $_POST['username'] : ''; ?>">
        </div>

        <div class="form-group">
            <label>Email:</label>
            <input type="email" name="email" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>">
        </div>

        <div class="form-group">
            <label>Password:</label>
            <input type="password" name="password">
        </div>

        <button type="submit" class="btn">Register</button>
    </form>
</div>

<?php require_once '../includes/footer.php'; ?>

